# Handoff: Shipyard Marketing Landing Page

## Overview
A single-page marketing site for **Shipyard** — an agentic-AI product that plugs into your codebases and environments, auto-discovers every service/owner/dependency, and lets you create, maintain, and query your infrastructure in plain English. The page sells the product to engineering leads and CTOs at 50–150 person companies and drives a single primary action: **"Map your context"** (early-access signup).

The design is a confident **light theme** with Electric Green as the signature accent (deliberately NOT the cliché dark-mode-with-one-neon-accent AI-SaaS look).

## About the Design Files
The file in this bundle (`Shipyard Landing.dc.html`) is a **design reference created in HTML** — a working prototype showing the intended look, motion, and interaction. It is **not production code to copy directly**.

> It is authored in a bespoke streaming-HTML component format (`.dc.html`). Treat it as a visual + behavioral spec only. **Do not** try to port the `.dc.html` runtime, its `{{ }}` template holes, `<sc-for>`/`<sc-if>` tags, or the `Component`/`renderVals()` logic class. Read it for layout, copy, color, spacing, and animation values, then **recreate the design in the target codebase's existing environment** (React/Vue/Svelte/etc.) using its established component patterns, styling system, and conventions. If no front-end environment exists yet, implement it in React + your styling solution of choice (CSS Modules, Tailwind, styled-components).

## Fidelity
**High-fidelity.** Final colors, typography, spacing, copy, and interactions are all specified below and in the prototype. Recreate the UI pixel-accurately using the codebase's existing libraries and patterns. The one known gap: several **third-party tool logos in the integrations carousel are simplified placeholder SVGs** and must be swapped for the real brand marks (see Assets).

---

## Brand System / Design Tokens

### Colors
| Token | Hex | Usage |
|---|---|---|
| Electric Green (primary) | `#00E87A` | Primary CTAs, logo fill, accents, highlights |
| Deep Navy | `#0A2463` | Headings, dark sections, primary text on light |
| Bright Blue (gradient end) | `#1E5FCC` | Gradients, connector lines |
| Teal (accent) | `#00C9A7` | Eyebrow labels, secondary accents, check icons |
| Readable Green (text) | `#0BA45E` | Green text on light backgrounds (AA contrast) |
| Background white | `#FFFFFF` | Page background |
| Off-white | `#FAFAFA` | Alternating section bands, subtle fills |
| Border gray | `#EAEAEA` | All card/section borders |
| Body text | `#6B6B6B` | Body copy, muted text |
| Muted/disabled | `#9a9a9a` / `#c4c4c4` | "Before" column text + minus icons |

**Tints used (8-digit hex / rgba):** `#00E87A0a` (~4% green) for highlight column/cards, `#00E87A12`–`#00E87A14` for badges/icon chips, `#00E87A40` badge borders.

### Typography
- **Display:** `Sora` (700/800) — headings, numbers, wordmark, stat figures. Tight tracking: `-0.025em` to `-0.035em` on large headings.
- **Body:** `DM Sans` (400/500/600/700) — paragraphs, buttons, nav.
- **Mono:** `JetBrains Mono` (400/500/600) — eyebrow labels (uppercase, `letter-spacing:0.12em`), terminal/code, chips, integration tags.
- Google Fonts import: `Sora:400,500,600,700,800` · `DM Sans:400,500,600,700` · `JetBrains Mono:400,500,600`.

Heading scale (desktop): hero h1 `70px/1.0`; section h2 `38px/1.1`; sub-heads `28–36px`; body `16–20px`; eyebrow `13px` mono uppercase.

### Radius
- Buttons / inputs: `10–13px`
- Cards / chips: `14–18px`
- Large feature cards & panels: `18–24px`
- Logo icon: `18px` (on a 72-viewBox, scales to ~`10px` at 34px render) — effectively a rounded square.
- Pills/badges: `999px`

### Shadows
- Card hover lift: `0 18px 40px -22px rgba(10,36,99,0.3)`
- Elevated panels: `0 24px 60px -32px rgba(10,36,99,0.28)`
- Deep/feature: `0 30px 70px -42px rgba(10,36,99,0.3)`
- Navy terminal: `0 24px 60px -24px rgba(10,36,99,0.5)`
- Green CTA hover glow: `0 10px 26px rgba(0,232,122,0.4)`

### Spacing
- Page max-width: `1180px` (pricing `1100px`, feature panels `920–940px`), horizontal padding `32px`.
- Section vertical rhythm: `72–96px` top/bottom.
- Grid gaps: `20–24px` (cards), `28–56px` (split layouts).

### Logo
Rounded square, Electric Green fill, single-stroke "S" in Deep Navy. SVG (72×72 viewBox), reused at 34px (nav), 28px (footer), 32px (infra diagram):
```html
<svg viewBox="0 0 72 72" fill="none">
  <rect width="72" height="72" rx="18" fill="#00E87A"/>
  <path d="M53.4147 23.6177C54.6082 16.8494 48.567 10.7994 40.6885 9.41019C30.8404 7.67371 22.9238 12.2596 21.5599 19.9948C20.196 27.73 26.4077 32.8132 35.9148 36.4835C45.4219 40.1537 51.6335 45.2369 50.2696 52.9721C48.9057 60.7073 41.1596 64.3263 31.3115 62.5898C21.4634 60.8533 15.4222 54.8033 16.6157 48.035"
        stroke="#0A2463" stroke-width="8" stroke-linecap="round"/>
</svg>
```

---

## Screens / Views
Single scrolling page. Sections top-to-bottom:

### 1. Nav (sticky)
- **Layout:** sticky top bar, `68px` tall, `max-width:1180px`, translucent white (`rgba(255,255,255,0.82)` + `backdrop-filter: blur(12px) saturate(140%)`). Logo + wordmark left; links + CTA right (`margin-left:auto`).
- **Links:** Product · Integrations · Pricing (anchor jumps to `#product`, `#integrations`, `#pricing`). DM Sans 500, 15px, navy.
- **CTA:** "Map your context" — green fill `#00E87A`, navy text, `10px` radius, compass-style icon. Hover: `translateY(-1px)` + green glow.
- **Scroll behavior:** border-bottom + subtle shadow appear only after `scrollY > 8` (transparent border at top). Border `#EAEAEA`, shadow `0 1px 0 rgba(10,36,99,0.04)`.

### 2. Hero
- **Layout:** left-aligned text block (`max-width:780px`), then a full-width product visual below.
- **Badge:** pill, green tint bg + border, pulsing green dot, text "Agentic AI at the infrastructure-as-code layer".
- **H1:** "Your stack, mapped." — Sora 800, 70px, navy, `-0.035em`.
- **Subhead:** "Shipyard plugs straight into your codebases and environments, then maps every service, owner, and dependency for you. No YAML required." — 20px, `#6B6B6B`.
- **CTAs:** Primary "Map your context" (green, compass icon, hover lift+glow). Secondary "See it work" (white, `#EAEAEA` border, chevron, scrolls to `#product`).
- **Hero product visual (signature moment):** a navy "terminal" card inside a green-tinted (`#00E87A0a`) rounded frame. Mac traffic-light dots, title `shipyard · discover`, a "live" pulse indicator. **Lines of a discovery trace animate in one-by-one** (see Interactions). JetBrains Mono, 14.5px. Green `✓` / teal `→` glyphs, muted secondary lines, blinking cursor at the end.

### 3. Infra-layer graphic — "We live in your infrastructure layer."
- **Purpose:** visually convey that Shipyard threads through the stack.
- **Layout:** centered eyebrow + h2 + lead, then a white card (`max-width:920px`, radius 24) containing **three stacked tiers**:
  1. Top tier (`#FAFAFA` bar): label "Your code & services" + mono chips: `api-gateway`, `payments`, `web-app`, `workers`.
  2. **Connector row (reads up):** 3 vertical gradient lines, each with a teal dot animating **upward** (`flowUp`).
  3. Middle tier (**navy bar**, elevated): Shipyard logo + "Shipyard" + "reads context up, ships changes down" + a green "active" pulse tag. Subtle green sheen overlay.
  4. **Connector row (acts down):** 3 vertical gradient lines, green dots animating **downward** (`flowDown`).
  5. Bottom tier (`#FAFAFA` bar): label "Your cloud & environments" + chips: `compute`, `databases`, `queues`, `secrets`.

### 4. Problem — 3 columns
- Centered eyebrow "The problem" + h2 "A catalog you fill in by hand is a catalog that's always wrong."
- 3 cards (`repeat(3,1fr)`, gap 24), each: green-tint icon chip (48px, radius 13) + line-icon, h3, one-line body. Hover: `translateY(-4px)` + shadow + border turns `#00E87A55`.
  - "Discovery never finishes" — "Manual YAML is stale before the PR even merges."
  - "Ownership is tribal" — "It's 2am, prod is down, and nobody knows who owns this."
  - "Self-service doesn't exist" — "New service? File a ticket. Join the queue. Wait."

### 5. Product showcase 1 — "Every other IDP starts empty. Shipyard starts full."
- **Split** `0.85fr / 1.15fr`, gap 56. Left text (eyebrow "Auto-discovery", h2, one paragraph). Right: a **Service Catalog map mockup** — white card with header (`24 services · auto` teal tag), dotted-grid canvas with SVG dependency curves and 5 floating service nodes (name, status dot, mono stack, owner avatar). Nodes gently float (`floaty`); a green scan bar sweeps across (`scan`). The "payments-service" node is the green-highlighted focal node.

### 6. Product showcase 2 — "Talk to your infrastructure." (Create / Maintain / Context)
- **Interactive.** Centered eyebrow "Natural language → IaC" + h2 + lead.
- **Layout** `0.82fr / 1.18fr`. Left: 3 selectable capability cards (Create, Maintain, Context). Right: a live demo terminal panel that swaps with the selected capability.
- **Cards:** icon chip + title + blurb. The **active** card has green border `#00E87A`, `#00E87A0a` bg, lift `translateY(-2px)`, green shadow, and a green icon chip. Inactive: `#EAEAEA` border, white bg, `#FAFAFA` icon chip.
- **Demo panel:** terminal header (title + teal tag), the natural-language prompt in a green-bordered box (prefixed `›`), a "result" label, and a navy output block (mono) of generated infra code / answer. Each swap fades (`fadeSwap`).
  - **Create** → tag `terraform plan`; prompt "A Go service that reads the orders queue and writes enriched events to a new Postgres table. Owned by payments."; output = green `+` resource adds, "Plan: 3 to add…".
  - **Maintain** → tag `terraform apply`; prompt "Scale payments-service to 4 replicas and rotate its database credentials before Friday's launch."; output = amber `~` changes, "Plan: 0 to add, 2 to change…".
  - **Context** → tag `live context`; prompt "Who owns auth-gateway, and what breaks if it goes down?"; output = owner, deps, and 3 impacted services (amber).

### 7. Integrations carousel — "One agent, plugged into your whole toolchain."
- `#FAFAFA` band, eyebrow "Integrations · MCP", h2, lead.
- **Two infinite marquee rows** (row A scrolls left `44s`, row B scrolls right `52s`), edge-masked with a horizontal fade. Each row duplicates its set for a seamless loop. **Pause on hover** of a row.
- **Each pill:** white, `#EAEAEA` border, radius 14, holds a **brand glyph (20px) + wordmark** (Sora 700, 18px, brand color). **Grayscale + 55% opacity at rest; full color + lift + shadow on hover** (200ms).
- Tools: Row A — GitHub, Terraform, AWS, Kubernetes, Datadog, PagerDuty, GitLab, Pulumi, GCP, Vault. Row B — Slack, Linear, Jira, Notion, Sentry, Grafana, Vercel, Snowflake, Azure, Cloudflare.

### 8. The Impact — Before vs With Shipyard
- Eyebrow "The impact" + h2 "See the difference, for you and your team."
- **Segmented toggle** ("Just me" / "My whole team") with a sliding green pill. Swaps the comparison below (`fadeSwap`).
- **Comparison card** (`max-width:940px`, radius 24, overflow hidden): a 3-column grid `1.15fr 1fr 1fr`. Header row (empty / "Before Shipyard" muted mono / "With Shipyard" green mono on `#00E87A0a`). Then 3 dimension rows, each: dimension label (navy 600) · before value (muted, gray minus icon) · with-Shipyard value (navy bold + teal check, on the tinted `#00E87A0a` column). The green column reads as one continuous highlighted strip.
  - **Just me:** Time to a full map (Days of digging → 5 minutes) · Getting connected (Wire up apps one by one → 10 apps wired in, free) · YAML to maintain (Endless, always stale → Zero lines, ever).
  - **My whole team:** 2am incident, find the owner (Guesswork and frantic pings → One click to the owner) · Catalog accuracy (Stale the day it's written → 100% mapped, always) · Shipping a new service (File a ticket, then wait → Self-served, zero tickets).

### 9. Pricing — 3 tiers
- `#FAFAFA` band, eyebrow + h2 "Start free. Scale when you're ready." 3 cards `repeat(3,1fr)`, gap 22.
  - **Solo** — Free. CTA "Map your context" (outline). Features: First **10** app integrations · Full catalog & dependency map · Community support.
  - **Solo Premium** — **$7 / month**, navy card (elevated `translateY(-6px)`, "POPULAR" green badge, green CTA "Go Premium"). Features: **Unlimited** third-party integrations · Manage across all your apps & tools · Plain-English service creation · Priority support.
  - **Enterprise** — Pay as you go. CTA "Talk to us" (outline). Features: Everything in Premium, org-wide · Usage-based, scales with your estate · SSO, audit log, priority SLA.

### 10. Final CTA
- Full-width **Deep Navy** section (the only dark block). Radial blue glow top-right. h2 "Map your context in **5 minutes.**" (5 minutes in green). Lead about read-only access. Single green CTA "Map your context".

### 11. Footer
- Thin, `#EAEAEA` top border. Logo + wordmark, "© 2026 Shipyard, Inc.", right-aligned links: Privacy · Terms · Integrations · X. Link hover → navy.

---

## Interactions & Behavior
- **Scroll reveal (used consistently everywhere):** every `[data-reveal]` element starts `opacity:0; translateY(26px)` and animates to visible via IntersectionObserver (threshold 0.12, `rootMargin: 0px 0px -8% 0px`), transition `opacity .55s ease-out, transform .55s ease-out`. One effect, applied uniformly — do not vary per section.
- **Hero discovery trace:** lines append on an interval of **560ms** each; blinking cursor shows while incomplete; stops at the last line. On a real build, trigger on load or on scroll-into-view.
- **Capability selector (Create/Maintain/Context):** click swaps the demo panel content + moves the active styling. Default = Create.
- **Impact toggle:** "Just me" / "My whole team" swaps the comparison table; sliding pill animates `transform .32s cubic-bezier(.65,.05,.36,1)`. Default = Just me.
- **Integrations marquee:** infinite CSS translateX loops (`marquee` keyframe to `-50%`); duplicated content; `animation-play-state:paused` on row hover. Logo pills: grayscale→color, lift, shadow on hover (200ms).
- **Buttons / cards hover:** lift + shadow/glow, 150–200ms ease.
- **Nav:** border/shadow toggle on scroll past 8px.
- **No** parallax, 3D tilt, or particle effects (intentional — audience trusts restraint).

### Keyframes used
- `traceIn` (fade+rise for trace lines), `blink` (cursor), `pulse` (live dots), `marquee` (carousel), `fadeSwap` (panel swaps), `scan` (catalog scan bar), `floaty` (catalog nodes), `flowDown` / `flowUp` (infra connector dots).

## State Management
- `traceCount` (int) — how many hero trace lines are visible (interval-driven).
- `scrolled` (bool) — nav scrolled state.
- `activeCap` ('create' | 'maintain' | 'context') — selected capability.
- `impactView` ('solo' | 'team') — impact toggle.
- Data: a static `trace()` line list; capability demo definitions (title, tag, prompt, result label, output lines); two logo arrays (name + brand color + glyph). No data fetching — all content static.

## Responsive behavior
The prototype is built desktop-first at ~1180px. For production, collapse: 3-col grids → 1 col on mobile; hero h1 scale down (~40–44px); split layouts stack (text above visual); impact comparison can become stacked before/after pairs; nav links → menu. (Exact mobile specs not in scope of this prototype — apply the codebase's responsive conventions.)

## Assets
- **Shipyard logo:** inline SVG above — reuse as a component.
- **Section line-icons** (problem cards, CTAs, checks, capability icons): simple inline stroke SVGs (`stroke:#0A2463`, width ~2). Reproduce or replace with the codebase's icon set (e.g. Lucide). Check icon uses teal `#00C9A7`.
- **Integration tool logos — ACTION REQUIRED:** the carousel currently uses **simplified placeholder SVG glyphs** for GitHub, Terraform, AWS, Kubernetes, Datadog, PagerDuty, GitLab, Pulumi, GCP, Vault, Slack, Linear, Jira, Notion, Sentry, Grafana, Vercel, Snowflake, Azure, Cloudflare. **Replace these with the official brand marks** (each vendor's brand/press kit, or a vetted icon set such as Simple Icons). Keep the grayscale-at-rest → full-color-on-hover treatment. Respect each brand's trademark usage guidelines.
- **Fonts:** Sora, DM Sans, JetBrains Mono via Google Fonts (or self-host).
- No photography. No AI "gradient orb" backgrounds (explicitly avoided).

## Files
- `Shipyard Landing.dc.html` — the full design reference (all sections, animations, and interactions).
